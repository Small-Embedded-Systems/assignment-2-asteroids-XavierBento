#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>
#include <display.h>
#include <mbed.h>


#include "model.h"
#include "view.h"
#include "controller.h"


float elapsedtime; 
int   score = 0;
int   livesleft = 5;
int ship_shield = 3;
struct ship player;
bool gamePaused = true;


float Dt = 0.01f;

Ticker model, view, controller;

static void death();

/* Button used to continue playing from paused state */
DigitalIn userbutton(P2_10,PullUp);

int main()
{
    init_DBuffer();
    
    view.attach( draw, 0.025);
    model.attach( gamePhysics, Dt);
    controller.attach( controls, 0.025);
    
   
    while( userbutton.read() ){
        gamePaused=true;
    }
		gamePaused = false;
		
		
    while(true) {
			
			if(ship_shield < 1) {
				death();
			}
			
			if(livesleft < 0) {
				livesleft = 5;
				score = 0;
				elapsedtime = 0;
			}
    }
}


static void death() {
	livesleft --;
	while( userbutton.read() ){
        gamePaused=true;
    }
	ship_shield = 3;
	gamePaused = false;
}
