#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <mbed.h>


#include "model.h"
#include "asteroids.h"

/* Joystick 5-way switch */
enum position { RIGHT,DOWN,LEFT,UP,CENTRE };
DigitalIn joystick[] = {P5_0, P5_1, P5_4, P5_2, P5_3};
static bool jsPrsd(position);


void controls(void)
{
	
	if (!gamePaused) {
		
		if (jsPrsd(LEFT)) {
			player.headingDirection -= 5;
		}
		
		else if (jsPrsd(RIGHT)) {
			player.headingDirection += 5;
		}
		
		else if (jsPrsd(UP)) {
			player.enginesThrust = 1;
		}
		
		else if (jsPrsd(DOWN)) {
			player.enginesThrust = -1;
		}
		
		else if (jsPrsd(CENTRE)) {
			player.fire = true;
		}
		
		if (!jsPrsd(DOWN) && !jsPrsd(UP)) {
			player.enginesThrust = 0;
		}
	}
}

/* Returns true if the button given has been pressed */
bool jsPrsd(position p) {
	bool result = false;
	static uint32_t state;
	state = joystick[p].read();
  if (state == 0) {
		result = true;
	}
	return result;
}
