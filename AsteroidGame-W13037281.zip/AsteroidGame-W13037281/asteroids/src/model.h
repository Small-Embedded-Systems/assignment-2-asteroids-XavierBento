/* Variable*/

struct point {
    float x,y;
};
typedef struct point coordinate_t;
typedef struct point vector_t;

struct ship {
		int headingDirection; 
		int enginesThrust;
		bool fire;
    coordinate_t position;
    vector_t     velocity;
};

/* Typedef struct type for the Asteroid structure - Used in the missile linked list */
typedef struct asteroid {
    coordinate_t position;
		vector_t 	velocity;
		int size;
		bool live;
    struct asteroid *next;
} asteroid_t;

/* Typedef struct type for the Missile structure - Used in the missile linked list */
typedef struct missile {
    coordinate_t position;
		vector_t     velocity;
		bool live;
    struct missile *next;
} missile_t;


void gamePhysics(void);

/* The list pointers for Asteroid and missile */
asteroid_t *allocateNodeAsteroid(void);
missile_t *allocateNodeMissile(void);

extern struct	asteroid *asteCurrent; 
extern const int asteroidHpSize;
extern struct missile *missiCurrent; 
extern const int missileHpSize;
