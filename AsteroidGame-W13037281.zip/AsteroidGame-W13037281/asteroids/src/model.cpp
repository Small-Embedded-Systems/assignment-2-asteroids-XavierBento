#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>

#include "model.h"
#include "utils.h"
#include "asteroids.h"


static const int asteroidHpSize = 15;
static const int missileHpSize = 6;
static float missileCDown = 0;
static asteroid_t asteroidHp[asteroidHpSize];
static asteroid_t *asteroidFNodes;
static missile_t missileHp[missileHpSize];
static missile_t *missileFNodes;
struct asteroid *asteCurrent = NULL;
struct missile *missiCurrent = NULL;

static void asteroidFree_N(asteroid_t *i);
static void initAsteroidH(void); //Initialisation of Asteroid Heap
static void killAster(struct asteroid *a); //killed asteroid
static void asteroidPhys();
static void nAsteroid(void); // New Asteroid
static void astUpdate(struct asteroid *a); //Asteroid Update
static void asteroid_SWrap(struct asteroid *a); //Asteroid screen wrap
static void asteroid_PlayerColl(struct asteroid *a); //Asteroid Player Collision


static void missiFNode(missile_t *i);
static void initMissile(void); //Initialisation of  missile Heap
static void kMissile(struct missile *m); //kill missile
static void missiPhys(); //Missile Physics
static void nMissile(void); // new missile
static void missile_update(struct missile *m); // missile update
static void missiOffScr(struct missile *m); // Misile off screen


static void missiAsteroidColl(struct missile *m, struct asteroid *a); //Missile Asteroid Collision


static void rstShip(); //reset ship
static void shipMovmt(); //ship movement
static void fRotation(); //full rotation
static float direction_x(int headingDirection);
static float direction_y(int headingDirection);
static void scrWrap(); // Screen Wrap
static float getTSpeed(); //Get Total Speed
static void drag();
	
static void aster_scoring();

void gamePhysics(void)
{
	
	if (paused && lives == 5) {
		initAsteroidH();
		initMissile();
	}
	
	if (paused) {
		rstShip();
		killAster(asteCurrent);
		kMissile(missiCurrent);
	}
	
	else {
		shipMovmt();
		asteroidPhys();
		missiPhys();
		missiAsteroidColl(missiCurrent, asteCurrent);
		aster_scoring();
	}
}


void initAsteroidH(void) {
	int i;
	for (i = 0; i < (asteroidHpSize - 1); i++) {
		asteroidHp[i].next = &asteroidHp[i + 1];
	}
	asteroidHp[i].next = NULL;
	asteroidFNodes = &asteroidHp[0];
}


void initMissile(void) {
	int i;
	for (i = 0; i < (missileHpSize - 1); i++) {
		missileHp[i].next = &missileHp[i + 1];
	}
	missileHp[i].next = NULL;
	missileFNodes = &missileHp[0];
}


asteroid_t *allocateNodeAsteroid(void) {
	asteroid_t *asteroidNode = NULL;
	if (asteroidFNodes) {
		asteroidNode = asteroidFNodes;
		asteroidFNodes = asteroidFNodes->next;
	}
	return asteroidNode;
}


missile_t *allocateNodeMissile(void) {
	missile_t *missileNode = NULL;
	if (missileFNodes) {
		missileNode = missileFNodes;
		missileFNodes = missileFNodes->next;
	}
	return missileNode;
}


void asteroidFree_N(asteroid_t *i){
	i->next = asteroidFNodes;
	asteroidFNodes = i;
}

void missiFNode(missile_t *i){
	i->next = missileFNodes;
	missileFNodes = i;
}


void rstShip() {
	player.headingDirection = 90;
	player.fire = false;
	player.position.x = 220;
	player.position.y = 120;
	player.velocity.x = 0;
	player.velocity.y = 0;
}

static void shipMovmt() {
	fRotation();
	scrWrap();
	float xperc = direction_x(player.headingDirection);
	float yperc = direction_y(player.headingDirection);
	
	if (getTSpeed() < 3)
	{
		
		if (player.enginesThrust < 0) {
			player.velocity.x -= (player.velocity.x / 10);
			player.velocity.y -= (player.velocity.y / 10);
		}
		
		else if (player.enginesThrust > 0) {
			player.velocity.x += player.enginesThrust * xperc * 0.0005;
			player.velocity.y -= player.enginesThrust * yperc * 0.0005;
		}
	}
	drag();
	
	player.position.x += player.velocity.x;
	player.position.y += player.velocity.y;
}

void fRotation() {
	if (player.headingDirection > 360) {
		player.headingDirection = 1;
	}
	else if (player.headingDirection < 1) {
		player.headingDirection = 360;
	}
}


void scrWrap() {
	if (player.position.x > 485) {
		player.position.x = 5;
	}
	else if (player.position.x < -5) {
		player.position.x = 475;
	}
	else if (player.position.y > 270) {
		player.position.y = 5;
	}
	else if (player.position.y < -5) {
		player.position.y = 265;
	}
}


float direction_x(int headingDirection) {
	float xperc;
	if (headingDirection <= 90) {
		xperc = headingDirection;
	}
	else if (headingDirection <= 180) {
		xperc = 90 - (headingDirection - 90);
	}
	else if (headingDirection <= 270) {
		xperc = 90 - (headingDirection - 90);
	}
	else if (headingDirection > 270) {
		xperc = - (360 - headingDirection);
	}
	return xperc;
}


float direction_y(int headingDirection) {
	float yperc;
	if (headingDirection <= 90) {
		yperc = 90 - headingDirection;
	}
	else if (headingDirection <= 180) {
		yperc = - (headingDirection - 90);
	}
	else if (headingDirection <= 270) {
		yperc = - (270 - headingDirection);
	}
	else if (headingDirection > 270) {
		yperc = headingDirection - 270;
	}
	return yperc;
}


float getTSpeed() {
	float speedx;
	float speedy;
	if (player.velocity.x < 0) {
		speedx = -player.velocity.x;
	}
	else {
		speedx = player.velocity.x;
	}
	if (player.velocity.y < 0) {
		speedy = -player.velocity.y;
	}
	else {
		speedy = player.velocity.y;
	}
	return speedx + speedy;
}


void drag() {
	player.velocity.x -= (player.velocity.x / 100);
	player.velocity.y -= (player.velocity.y / 100);
}

void asteroidPhys() {
	nAsteroid();
	astUpdate(asteCurrent);
	asteroid_SWrap(asteCurrent);
	asteroid_PlayerColl(asteCurrent);
}


void asteroidValues(struct asteroid *a) {
	a->position.x = randrange(20,461);
	a->position.y = randrange(20,241);
	a->size = randrange(10, 31);
	a->velocity.x = randrange(-10, 10);
	a->velocity.y = randrange(-10, 10);
			
			while (player.position.x > (a->position.x - (a->size) - 15) 
				&& player.position.x < (a->position.x + (a->size) + 15) 
				&& player.position.y > (a->position.y - (a->size) - 15)
				&& player.position.y < (a->position.y + (a->size) + 15)) {
					a->position.x = randrange(20,461);
					a->position.y = randrange(20,241);
				}
	a->live = true;
}


void nAsteroid() {
	struct asteroid *nAsteroid = allocateNodeAsteroid();
	if (nAsteroid) {
		nAsteroid->next = asteCurrent;
		asteCurrent = nAsteroid;
		asteroidValues(nAsteroid);
	}
}


void killAster(struct asteroid *a) {
	for (; a; a = a->next) {
			a->live = false;
	}
}


void missiPhys() {

	if (player.fire && missileCDown < 0) {
		nMissile();
		missileCDown = 0.5;
	}
	player.fire = false;
	missileCDown -= Dt;
	
	missile_update(missiCurrent);
	missiOffScr(missiCurrent);
}


void missileValues(struct missile *m) {
	m->velocity.x = direction_x(player.headingDirection) * 0.01;
	m->velocity.y = -direction_y(player.headingDirection) * 0.01;
	m->position.x = player.position.x + m->velocity.x * 10;
	m->position.y = player.position.y + m->velocity.y * 10;
	m->live = true;;
}


void nMissile() {
	struct missile *nMissile = allocateNodeMissile();
	if (nMissile) {
		nMissile->next = missiCurrent;
		missiCurrent = nMissile;
		missileValues(nMissile);
	}
}


void kMissile(struct missile *m) {
	for (; m; m = m->next) {
			m->live = false;
	}
}


void astUpdate(struct asteroid *a) {
	for (; a; a = a->next) {
		a->position.x += a->velocity.x/25;
		a->position.y += a->velocity.y/25;
		if (a->next->live == false) {
			struct asteroid *dead = a->next;
			a->next = a->next->next;
			asteroidFree_N(dead);
		}
	}
}


void missile_update(struct missile *m) {
	for (; m; m = m->next) {
		m->position.x += m->velocity.x;
		m->position.y += m->velocity.y;
		if (m->next->live == false) {
			struct missile *dead = m->next;
			m->next = m->next->next;
			missiFNode(dead);
		}
	}
}

void asteroid_SWrap(struct asteroid *a) {
	for (; a; a = a->next) {
		if (a->position.x > 480) {
			a->position.x = 0;
		}
		else if (a->position.x < 0) {
			a->position.x = 480;
		}
		else if (a->position.y > 270) {
			a->position.y = 0;
		}
		else if (a->position.y < 0) {
			a->position.y = 270;
		}
	}
}

void missiOffScr(struct missile *m) {
	for (; m; m = m->next) {
		if (m->position.x > 480 || m->position.x < 0 ||
						m->position.y > 270 || m->position.y < 0) {
			m->live = false;
		}
	}
}


void asteroid_PlayerColl(struct asteroid *a) {
	for (; a; a = a->next) {
		if (player.position.x > (a->position.x - (a->size) - 8) 
				&& player.position.x < (a->position.x + (a->size) + 8) 
				&& player.position.y > (a->position.y - (a->size) - 8)
				&& player.position.y < (a->position.y + (a->size) + 8)
				&& a->live == true)
		{
			a->live = false;
			shield --;
		}
	}
}



void missiAsteroidColl(struct missile *m, struct asteroid *a) {
	for (; m; m = m->next) {
		for (; a; a = a->next) {
			if (m->position.x > (a->position.x - (a->size)) 
					&& m->position.x < (a->position.x + (a->size)) 
					&& m->position.y > (a->position.y - (a->size))
					&& m->position.y < (a->position.y + (a->size))
					&& a->live == true && m->live == true)
			{
				a->live = false;
				m->live = false;
			}
		}
	}
}


void aster_scoring() {
	elapsed_time += Dt;
	if (elapsed_time > score) {
		score ++;
	}
}
