#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>
#include <display.h>
#include <mbed.h>


#include "asteroids.h"
#include "model.h"
#include "utils.h"

Display *graphics = Display::theDisplay();

const colour_t background = rgb(0,51,102); 

static void drawStartGame();
static void drawResumeGame();
static void draw_GameOver();
static void drawScreenLayout();
static void drawShipStructure();
static void drawShieldStructure();
static void drawAsteroidsStructure(struct asteroid *a);
static void drawMissilesStructure(struct missile *m);
static coordinate_t getPoint(coordinate_t origin, int basex, int basey, float headingD);

/* Double Buffering functions */
void init_DBuffer(void)
{   
  uint16_t *bufferbase = graphics->getFb();
  uint16_t *nextbuffer = bufferbase+ (480*272);
  LPC_LCD->UPBASE = (uint32_t)nextbuffer;
}

void swap_DBuffer(void)
{  
  uint16_t *buffer = graphics->getFb();
  graphics->setFb( (uint16_t*) LPC_LCD->UPBASE);
  LPC_LCD->UPBASE = (uint32_t)buffer;
}

/* Main Draw Method */
void draw(void) {
  
	graphics->fillScreen(background);
	
	if (gamePaused && livesleft == 5) {
		drawStartGame();
	}
	
	else if (gamePaused && livesleft < 5 && livesleft >= 0) {
		drawResumeGame();
	}	
	
	else if (gamePaused && livesleft < 0) {
		draw_GameOver();
	}	
	
	else {
		drawAsteroidsStructure(asteCurrent);
		drawMissilesStructure(missiCurrent);
		drawScreenLayout();
		drawShipStructure();
	}
	
  swap_DBuffer();
}


static void drawStartGame() {
	graphics->setTextSize(2);
	graphics->setCursor(10, 10);
	graphics->printf("Xavier Bento");
	graphics->setCursor(330, 10);
	graphics->printf("ID: 13037281");
	graphics->setCursor(30, 70);
	graphics->setTextColor(WHITE);
	graphics->setTextSize(8);
	graphics->printf("ASTEROID GAME");
	graphics->setTextSize(2);
	graphics->setCursor(33, 140);
	graphics->printf("PRESS TOP RIGHT BUTTON TO START THE GAME");
	graphics->setTextSize(1);
	graphics->setCursor(180, 180);
	graphics->printf("JOYSTICK CONTROL");
	graphics->setCursor(180, 190);
	graphics->printf("UP      :   THRUST");
	graphics->setCursor(180, 200);
	graphics->printf("DOWN    :        BRAKE");
	graphics->setCursor(180, 210);
	graphics->printf("LEFT    :  TURN LEFT");
	graphics->setCursor(180, 220);
	graphics->printf("RIGHT   : TURN RIGHT");
	graphics->setCursor(180, 230);
	graphics->printf("CENTER  : FIRE BUTTON");
}


static void drawResumeGame() {
	graphics->setCursor(60, 90);
	graphics->setTextColor(WHITE);
	graphics->setTextSize(5);
	graphics->printf("SHIP DESTROYED");
	graphics->setCursor(20, 140);
	graphics->setTextSize(2);
	graphics->printf("PRESS TOP RIGHT BUTTON TO REAPPEAR");
	graphics->setTextSize(2);
	graphics->setCursor(150,190);
	graphics->printf("SCORE: %d", score);
	graphics->setCursor(137,210);
	graphics->printf("LIVES LEFT: %d", livesleft);
}


static void draw_GameOver() {
	graphics->setCursor(70, 90);
	graphics->setTextColor(WHITE);
	graphics->setTextSize(6);
	graphics->printf("YOU LOST - GAME OVER");
	graphics->setCursor(20, 150);
	graphics->setTextSize(2);
	graphics->printf("PRESS TOP RIGHT BUTTON TO RETRY");
	graphics->setTextSize(2);
	graphics->setCursor(145,200);
	graphics->printf("FINAL SCORE: %d", score);
}


static void drawScreenLayout() {
	graphics->setCursor(5,4);
	graphics->setTextSize(1);
	graphics->setTextColor(WHITE);
	graphics->printf("LIVES: %d", livesleft);
	graphics->setCursor(180,4);
	graphics->printf("SHIELD :");
	graphics->drawRect(229, 2, 62, 10, WHITE);
	graphics->setCursor(400,4);
	graphics->printf("ACTUAL SCORE: %d", score);
}


static void drawShipStructure() {
	float headingAngle = radians(player.headingDirection);
	coordinate_t front, backR, backL;
	
	front = getPoint(player.position, 0, -8, headingAngle);
	backL = getPoint(player.position, 5, 5, headingAngle);
	backR = getPoint(player.position, -5, 5, headingAngle);
	graphics->drawTriangle(front.x, front.y, backL.x, backL.y, backR.x, backR.y, WHITE);
	
	
	drawShieldStructure();
}


static void drawShieldStructure() {
	
	if (ship_shield == 3) {
		graphics->drawCircle(player.position.x, player.position.y, 12, GREEN);
		graphics->fillRect(230, 3, 60, 8, GREEN);
	}
	else if (ship_shield == 2) {
		graphics->drawCircle(player.position.x, player.position.y, 12, YELLOW);
		graphics->fillRect(230, 3, 40, 8, GREEN);
	}
	else {
		graphics->drawCircle(player.position.x, player.position.y, 12, RED);
		graphics->fillRect(230, 3, 20, 8, GREEN);
	}
}


static coordinate_t getPoint(coordinate_t origin, int basex, int basey, float headingD) {
	coordinate_t result;
	result.x = (basex * cos(headingD)) - (basey * sin(headingD));
	result.y = (basex * sin(headingD)) + (basey * cos(headingD));
	result.x += origin.x;
	result.y += origin.y;
	return result;
}


void drawAsteroidsStructure(struct asteroid *a) {
	while (a) {
		if (a->live) {
			graphics->drawCircle(a->position.x, a->position.y, a->size, WHITE);
		}
		a = a->next;
	}
}


void drawMissilesStructure(struct missile *m) {
	while (m) {
		if(m->live) {
			graphics->fillCircle(m->position.x, m->position.y, 2, RED);
		}
		m = m->next;
	}
}
