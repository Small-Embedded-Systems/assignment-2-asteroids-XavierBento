extern float elapsed_time; 
extern int   score;        
extern int   lives;        
extern int shield;				 
extern bool paused;				 
extern struct ship player; 

extern const float Dt; /* For physics, it is needed for consistent motion */
