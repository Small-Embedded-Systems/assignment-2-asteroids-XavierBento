/* utility functions */

extern float elapsedtime; 
extern int   score;        
extern int   livesleft;        
extern int ship_shield;				 
extern bool gamePaused;				 
extern struct ship player; 

extern const float Dt; /* For physics, it is needed for consistent motion */
